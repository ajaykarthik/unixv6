Operating Systems project 2
Ajay Karthik Ganesan and Ashwin Rameshkumar
This program, when run creates a virtual unix file system, which removes the V-6 file system size limit of 16MB
Compiled and run on cs3.utdallas.edu
compile as CC fsaccess.cc and run as ./a.out
Max file size is 12.5 GB
